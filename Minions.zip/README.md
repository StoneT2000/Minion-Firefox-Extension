# Minion-Firefox-Extension
A neat looking minion inspired Firefox extension. Changes a page to a minion!

Just search for this Firefox extension, add it to your browser, go to a page, right click said page, click minionize, and gaze your eyes on the minion
